from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, model_validator

from app.enums import ApprovalStatus, ApproveBidding, ProductStatus


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(min_length=8)


class UserShow(BaseModel):
    id: int
    username: str
    email: EmailStr

    model_config = ConfigDict(from_attributes=True)


class ProductCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    description: str | None = None
    start_price: int = Field(gt=0)


class ProductShow(BaseModel):
    id: int
    name: str
    description: str | None = None
    start_price: int
    current_price: int
    owner_id: int
    status: ProductStatus

    auction_started_at: datetime | None = None
    auction_ends_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class GetProductByStatus(BaseModel):
    status: ProductStatus


class ProductPatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    description: str | None = None
    start_price: int | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def validate_patch(self):
        if "name" in self.model_fields_set and self.name is None:
            raise ValueError("Name cannot be None when provided.")
        if "start_price" in self.model_fields_set and self.start_price is None:
            raise ValueError("Start price cannot be None when provided.")
        return self


class RoleShow(BaseModel):
    id: int
    name: str

    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str


class TokenData(BaseModel):
    username: str | None = None


class RefreshTokenRequest(BaseModel):
    refresh_token: str


class LogoutRequest(BaseModel):
    refresh_token: str


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(min_length=8)


class ResetPasswordToken(BaseModel):
    reset_token: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8)


class ProductStatusUpdate(BaseModel):
    status: ProductStatus


class ProductStatusRequestShow(BaseModel):
    id: int
    product_id: int
    requested_by: int
    requested_status: ProductStatus
    approval_status: ApprovalStatus
    created_at: datetime
    reviewed_at: datetime | None = None
    reviewed_by: int | None = None

    model_config = ConfigDict(from_attributes=True)


class BidCreate(BaseModel):
    amount: int = Field(gt=0)


class BidShow(BaseModel):
    id: int
    product_id: int
    user_id: int
    amount: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ApproveBidRequest(BaseModel):
    action: ApproveBidding


class LastBidderShow(BaseModel):
    id: int
    username: str

    model_config = ConfigDict(from_attributes=True)


class ProductApprovalShow(ProductShow):
    winning_bidder: LastBidderShow | None = None


class UserRoleUpdate(BaseModel):
    role_name: str


class ProductCSVImport(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    description: str | None = Field(default=None, max_length=255)
    start_price: int = Field(gt=0)

    model_config = ConfigDict(
        extra="forbid"
    )  # Forbid extra fields to ensure correct validation of CSV data.
