from sqlalchemy.orm import Session

from app import models
from app.enums import ApprovalStatus


class ProductStatusRequestRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_pending_by_product(self, product_id: int):
        return (
            self.db.query(models.ProductStatusRequest)
            .filter(
                models.ProductStatusRequest.product_id == product_id,
                models.ProductStatusRequest.approval_status == ApprovalStatus.PENDING,
            )
            .first()
        )

    def create(self, status_request: models.ProductStatusRequest):
        self.db.add(status_request)
        self.db.flush()
        return status_request

    def get_by_id(self, request_id: int):
        return (
            self.db.query(models.ProductStatusRequest)
            .filter(models.ProductStatusRequest.id == request_id)
            .first()
        )

    def get_by_id_for_update(self, request_id: int):
        return (
            self.db.query(models.ProductStatusRequest)
            .filter(models.ProductStatusRequest.id == request_id)
            .with_for_update()
            .populate_existing()
            .first()
        )
